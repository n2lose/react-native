import React, { Component } from 'React';
import { Navigator } from 'react-native';

import DashboardEmployee from './components/dashboard/dashboardEmployee.js';
import ViewListEmployee from './components/view/viewListEmployee.js';
import AddEmployee from './components/add/addEmployee.js';
import UpdateEmployee from './components/update/updateEmployee.js';

export default class App extends Component {
  constructor(props) {
    super(props);
  }

  renderScene(route, navigator ) {
    switch(route.name) {
      case 'dashboardEmployee':
        return (
         <DashboardEmployee 
            dashboardEmployee= {() => {navigator.push({name: "dashboardEmployee"})}}
            viewListEmployee= {() => {navigator.push({name: "viewListEmployee"})}}
            updateEmployee= {() => {navigator.push({name: "updateEmployee" })}}
            addEmployee= {() => {navigator.push({name: "addEmployee" })}}
          /> 
        )
      case 'addEmployee':
        return (
         <AddEmployee 
            addEmployee= {() => {navigator.push({name: "AddEmployee"})}}
          /> 
        )
      case 'updateEmployee':
        return (
         <UpdateEmployee 
            updateEmployee= {() => {navigator.push({name: "UpdateEmployee"})}}
            
          /> 
        )
      case 'viewListEmployee':
        return (
         <ViewListEmployee
            viewListEmployee= {() => {navigator.push({name: "ViewListEmployee"})}}
            updateEmployee= {() => {navigator.push({name: "updateEmployee" })}}
          /> 
        )
    };
  }

  render() {
    return (
      <Navigator 
        initialRoute={{name: "dashboardEmployee"}}
        renderScene={this.renderScene}
      />
    );
  }

}
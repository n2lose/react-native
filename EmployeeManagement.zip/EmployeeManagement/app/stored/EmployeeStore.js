let employees = [
  { emplId: 0, emplName: "John Dee", emplAge: 24, emplJob: "Front-end"},
  { emplId: 1, emplName: "Harry Pum", emplAge: 18, emplJob: "Fresher"},
  { emplId: 2, emplName: "Steven Ings", emplAge: 45, emplJob: "Consultant"},
];

let EmployeeStore = {
  getEmployeeList() {
    return employees;
  },
  addEmployee(objEmpl) {
    var idEmpl= employees.length + 1;
    objEmpl.id = idEmpl;
    employees.push(objEmpl);
  }
}

module.exports = EmployeeStore;
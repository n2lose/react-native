import React, { Component } from 'react';
import {View, Text, StyleSheet, TextInput, TouchableHighlight} from 'react-native';

export default class AddEmployee extends Component {
 
  addNewEmployee() {
    let empl = {
      emplName: this.state.emplName,
      emplAge: this.state.emplAge,
      emplJob: this.state.emplJob
    }
    this.props.addNewEmployee(empl);
  }

  render() {
    return(
      <View>
         <View style={styles.header}>
          <Text style={styles.textTitle}> Add New Employee </Text>
        </View>
        <View style={styles.rowInput}>
          <Text style={styles.lable}>Name</Text><TextInput style={styles.input} placeholder="Enter your name..." />
        </View>
        <View style={styles.rowInput}>
          <Text style={styles.lable}>Age</Text><TextInput style={styles.input} placeholder="Your age" />
        </View>
        <View style={styles.rowInput}>
          <Text style={styles.lable}>Job</Text><TextInput style={styles.input} placeholder="Your job title...." />
        </View>
         <TouchableHighlight style={styles.btnAdd}>
              <Text style={styles.btnText}>Add Employee</Text>
          </TouchableHighlight>
      </View>
    );
  }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },

    header: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center"
    },

    textTitle: {
        fontSize: 20
    },

    content: {
        flex: 4
    },

    rowInput: {
        flexDirection: "row",
        marginLeft: 10,
    },
    lable: {
        flex: 1,
        marginTop: 20
    },
    input: {
        flex: 3
    },
    btnAdd: {
        backgroundColor: "green",
        padding: 5,
        alignItems: "center",
        justifyContent: "center",
        margin: 10,
    },
    btnText: {
        color: "white"
    }

});
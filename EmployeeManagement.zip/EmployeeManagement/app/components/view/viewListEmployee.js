import React, { Component } from 'react';
import {View, Text, ListView, StyleSheet, TouchableHighlight } from 'react-native';

let EmployeeStore = require("../../stored/EmployeeStore");
let listEmpl = [];

export default class ViewListEmployee extends Component {
  constructor(props) {
    super(props);
    listEmpl = EmployeeStore.getEmployeeList();
    this.ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {
        employees: listEmpl,
    }
  }
  render() {
    return(
      <View> 
        <View style={styles.header}>
          <Text style={styles.textTitle}> Employee </Text>
        </View>
        <View style={styles.content}>
          <ListView 
                dataSource={this.ds.cloneWithRows(this.state.employees)}
                renderRow={
                    (rowData) => {
                        return (
                            <TouchableHighlight>
                                <View style={styles.rowInfo}> 
                                    <Text>Name: {rowData.emplName}</Text>
                                    <Text>Age: {rowData.emplAge} </Text>
                                    <Text>Job title: {rowData.emplJob} </Text>
                                </View>
                            </TouchableHighlight>
                        );
                    }
                }
            />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },

    header: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center"
    },

    textTitle: {
        fontSize: 20
    },

    content: {
        flex: 4
    },

    rowInfo: {
        padding: 10,
        borderTopWidth: 1,
        borderTopColor: "#dddddd",
        alignItems: "center",
        justifyContent: "center"
    },

    buttonAddStudent: {
        backgroundColor: "green",
        padding: 5,
        alignItems: "center",
        justifyContent: "center",
        margin: 10,
    },
    textButton: {
        color: "white"
    }

});
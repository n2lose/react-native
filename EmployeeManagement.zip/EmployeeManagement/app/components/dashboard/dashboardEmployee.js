import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableHighlight } from 'react-native';


export default class DashboardEmployee extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return(
      <View style={styles.container}> 
        <TouchableHighlight  onPress={() => {this.props.viewListEmployee()}} style={[styles.Items, styles.ItemsView ]}>
          <Text style={styles.TextItems}>View</Text>
        </TouchableHighlight>
        
        <TouchableHighlight  onPress={() => {this.props.addEmployee()}} style={[styles.Items, styles.ItemsAdd]}>
          <Text style={styles.TextItems}>Add</Text>
        </TouchableHighlight>
        
        <TouchableHighlight  onPress={() => {this.props.updateEmployee()}} style={[styles.Items, styles.ItemsEdit]}>
          <Text style={styles.TextItems}>Edit</Text>
        </TouchableHighlight>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  Items: {
    flex: 1,
    width: 320,
    alignItems: 'center',
  },
  ItemsView: {
    backgroundColor: 'powderblue'
  },
  ItemsAdd: {
    backgroundColor: 'skyblue'
  },
  ItemsEdit: {
    backgroundColor: 'steelblue'
  },
  TextItems: {
    fontSize: 20,
  }
});
import React from "react";
import {
  AppRegistry
} from "react-native";

import App from "./app/App.js";


AppRegistry.registerComponent('EmployeeManagement', () => App);

import React, { Component } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity
} from 'react-native';

export default class DashboardComponent extends Component {
  render() {
    return(
      <View>
        <Text>Home page</Text>
        <TouchableOpacity  onPress={this.props.RouteToViewListUsers}>
          <Text>View List Users</Text>
        </TouchableOpacity>
      </View>
    );
  }
}
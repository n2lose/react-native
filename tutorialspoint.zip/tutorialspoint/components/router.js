import React, { Component } from 'react';
import {
  Navigator,
  TouchableOpacity
} from 'react-native';

import DashboardComponent from './home/dashboard.js';
import AboutComponent from './about/about.js';
import ViewListUserComponent from './users/view.js';

export default class RouterComponent extends Component {
  renderScene(route, navigator) {
     if(route.name == 'Home') {
         return (
            <DashboardComponent RouteToViewListUsers={() => {
              navigator.push({name: 'ViewListUser'});
            }}/>
         )
      }
      if(route.name == 'About') {
         return (
            <AboutComponent />
         )
      }
      if(route.name == 'ViewListUser') {
         return (
            <ViewListUserComponent />
         )
      }

  }

  render() {
    return(
      <Navigator 
        initialRoute={{name: "Home"}}
        renderScene={this.renderScene}
      />
    );
  }
}

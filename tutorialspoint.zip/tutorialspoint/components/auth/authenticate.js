import React, { Component } from 'react';
import {
  Text,
  View
} from 'react-native';

export default class AuthenticateComponent extends Component {
  render() {
    return(
      <View>
        <Text>Login page</Text>
      </View>
    );
  }
}

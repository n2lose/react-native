import React, { Component } from 'react';

import {
  Navigator
} from 'react-native';

import RouterComponent from './router.js';
import AuthenticationComponent from './auth/authenticate.js';

export default class AppRouter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoggedIn: true
    }
  }

  componentWillMount() {
    let isAuthenticated;
    if(!this.state.isLoggedIn) {
      isAuthenticated = false;
    } else {
      isAuthenticated = true;
    }

    this.setState({
      isLoggedIn: isAuthenticated
    });
  }

  render() {
    if(this.state.isLoggedIn) {
      return(
        <RouterComponent />
      );
    } else {
      return (
        <AuthenticationComponent />
      );
    }
  }
}
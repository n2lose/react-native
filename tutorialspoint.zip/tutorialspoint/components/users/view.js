import React, { Component } from 'react';
import {
  Text,
  View,
  ListView,
  
} from 'react-native';

let DataUsers = require('../datastored/users.js');
let listUsers = [];
export default class ViewListUserComponent extends Component {

  constructor(props) {
    super(props);
    listUsers = DataUsers.getListUsers();
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 != r2});
    this.state = {
      dataSource: ds.cloneWithRows(listUsers)  
    }
  }

  createRowItem(property) {
    return(
      <View>
        
      </View>
    );
  }



  render() {
    return(
      <View>
        <Text>View List Users</Text>
      </View>
    );
  }
}
import React, { Component } from 'react';

import {
  Text,
  View
} from 'react-native';

export default class AboutComponent extends Component {
  render() {
    return(
      <View>
        <Text>About page</Text>
      </View>
    );
  }
}
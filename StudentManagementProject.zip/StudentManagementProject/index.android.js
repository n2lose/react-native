import React from "react";
import {
  AppRegistry
} from "react-native";

import App from "./components/App.js";


AppRegistry.registerComponent('StudentManagementProject', () => App);

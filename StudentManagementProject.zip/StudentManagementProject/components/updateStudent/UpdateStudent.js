import React, {Component} from "react";

import {
    StyleSheet,
    View,
    Text,
    TextInput,
    TouchableOpacity,
    Picker
} from "react-native";



export default class UpdateStudent extends Component {
    constructor(props) {
        super(props);
        let student = this.props.student;
        this.state= {
            student: student,
            studentName: student.studentName,
            studentAge: student.studentAge,
            studentAddress: student.studentAddress,
            studentTitle: student.studentTitle
        }
    }

    _updateInfoStudent() {
        student = {
            studentId: this.state.student.studentId,
            studentName: this.state.studentName,
            studentAge: this.state.studentAge,
            studentAddress: this.state.studentAddress,
            studentTitle: this.state.studentTitle
        }
        this.props.updateInfoStudent(student);
    }
    _deleteStudent() {
        this.props.deleteStudent(this.state.student);
    }

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.rowInput}>
                    <Text style={styles.lable}> title: </Text>
                    <Picker
                        style={styles.input}
                        selectedValue= {this.state.studentTitle}
                        enabled= {true}
                        mode= "dropdown"
                        onValueChange= {(value, index) => {this.setState({studentTitle: value})}}>
                        <Picker.Item label="Mr" value="Mr"/>
                        <Picker.Item label="Mrs" value="Mrs"/>
                        <Picker.Item label="Miss" value="Miss"/>
                        <Picker.Item label="Sir" value="Sir"/>
                        <Picker.Item label="dr" value="dr"/>
                    </Picker>
                </View>
                <View style={styles.rowInput}>
                    <Text style={styles.lable}> name: </Text>
                    <TextInput
                        style={styles.input}
                        onChangeText={(text) => this.setState({studentName: text})}
                        value={this.state.studentName}
                    />
                </View>
                <View style={styles.rowInput}>
                    <Text style={styles.lable}> age: </Text>
                    <TextInput
                        type="number"
                        style={styles.input}
                        onChangeText={(text) => this.setState({studentAge: text})}
                        value={this.state.studentAge.toString()}
                      />
                </View>
                <View style={styles.rowInput}>
                    <Text style={styles.lable}> adddress: </Text>
                    <TextInput
                          style={styles.input}
                          onChangeText={(text) => this.setState({studentAddress: text})}
                          value={this.state.studentAddress}
                      />
                </View>
                <View style={styles.button}>
                    <TouchableOpacity onPress={() => {this._updateInfoStudent()}}>
                        <View style={styles.buttonUpdateStudent}>
                            <Text style={styles.textButton}> update student </Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => {this._deleteStudent()}}>
                        <View style={styles.buttonDeleteStudent}>
                            <Text style={styles.textButton}> delete student </Text>
                        </View>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }
}

UpdateStudent.PropType= {
    updateInfoStudent: React.PropTypes.func.isRequired,
    deleteStudent: React.PropTypes.func.isRequired
}

const styles = StyleSheet.create({
    rowInput: {
        flexDirection: "row",
    },
    lable: {
        flex: 1,
        marginTop: 20
    },
    input: {
        flex: 3
    },
    button: {
        flexDirection: "row"
    },
    buttonUpdateStudent: {
        backgroundColor: "green",
        padding: 5,
        alignItems: "center",
        justifyContent: "center",
        margin: 10,
        flex: 1
    },
    buttonDeleteStudent: {
        backgroundColor: "blue",
        padding: 5,
        alignItems: "center",
        justifyContent: "center",
        margin: 10,
        flex: 1
    },
    textButton: {
        color: "white"
    }
});
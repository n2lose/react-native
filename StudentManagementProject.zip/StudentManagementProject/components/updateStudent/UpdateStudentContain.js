import React, {Component} from "react";

import {

} from "react-native";

import UpdateStudent from "../updateStudent/UpdateStudent.js";

let StudentConstant = require("../../constant/StudentConstant");
let AppDispatcher = require("../../dispatcher/AppDispatcher");

let pushNotification = require("../pushNotification/PushNotificationObject");

export default class UpdateStudentContain extends Component {
    constructor(props) {
        super(props);
    }

    updateInfoStudent(student) {
        AppDispatcher.dispatch({
            action: StudentConstant.UPDATE_STUDENT,
            student: student,
        });
        let messageContent = "student: " + student.studentName + " is updated success";
        pushNotification.notificationAction(messageContent);
        this.props.viewListStudents();
    }

    deleteStudent(student) {
        AppDispatcher.dispatch({
            action: StudentConstant.REMOVE_STUDENT, 
            student: student
        });
        let messageContent = "student: " + student.studentName + " is deleted success";
        pushNotification.notificationAction(messageContent);
        this.props.viewListStudents();
    }

    render() {
        return (
            <UpdateStudent 
                student={this.props.student}
                updateInfoStudent= {(student) => {this.updateInfoStudent(student)}}
                deleteStudent= {(student) => {this.deleteStudent(student)}}/>
        );
    }
}
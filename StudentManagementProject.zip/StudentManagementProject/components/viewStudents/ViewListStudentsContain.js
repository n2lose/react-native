import React, {Component} from "react";

import {

} from "react-native";

import ViewListStudents from "../viewStudents/ViewListStudents.js";

let StudentStore = require("../../stores/StudentStore");
let listStudents = [];
export default class ViewStudentContain extends Component {

    constructor(props) {
        super(props);
        listStudents = StudentStore.getStudents();
        this.state= {
            students: listStudents
        }
    }

    render() {
        return (
            <ViewListStudents 
                students= {this.state.students}
                updateStudent= {(student) => {this.props.updateStudent(student)}}
                viewAddStudent= {() => {this.props.viewAddStudent()}}/>
        );
    }

    componentDidMount() {
        StudentStore.addChangeListener(() => {this.setState({students: StudentStore.getStudents()})});
    }
}
import React, {Component} from "react";

import {
    StyleSheet,
    View,
    Text,
    TextInput,
    ListView,
    TouchableOpacity,

} from "react-native";


export default class ViewListStudents extends Component {
    constructor(props) {
        super(props);
        listStudents = this.props.students;
        this.ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
        this.state = {
            students: listStudents,
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.header}>
                    <Text style={styles.textTitle}> Student Management Project</Text>
                    <TouchableOpacity onPress={() => {this.props.viewAddStudent()}}>
                        <View style={styles.buttonAddStudent}>
                            <Text style={styles.textButton}> add student </Text>
                        </View>
                    </TouchableOpacity>
                </View>
                <View style={styles.content}>
                    <ListView 
                        dataSource={this.ds.cloneWithRows(this.state.students)}
                        renderRow={
                            (rowData) => {
                                return (
                                    <TouchableOpacity onPress={() => {this.props.updateStudent(rowData)}}>
                                        <View style={styles.rowInfo}> 
                                            <Text> {rowData.studentTitle} {rowData.studentName} </Text>
                                            <Text> {rowData.studentAge} </Text>
                                            <Text> {rowData.studentAddress} </Text>
                                        </View>
                                    </TouchableOpacity>
                                );
                            }
                        }
                    />
                </View>
            </View>
        );
    }

}

ViewListStudents.PropType= {
    updateStudent: React.PropTypes.func.isRequired
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },

    header: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center"
    },

    textTitle: {
        fontSize: 20
    },

    content: {
        flex: 4
    },

    rowInfo: {
        padding: 10,
        borderTopWidth: 1,
        borderTopColor: "#dddddd",
        alignItems: "center",
        justifyContent: "center"
    },

    buttonAddStudent: {
        backgroundColor: "green",
        padding: 5,
        alignItems: "center",
        justifyContent: "center",
        margin: 10,
    },
    textButton: {
        color: "white"
    }

});

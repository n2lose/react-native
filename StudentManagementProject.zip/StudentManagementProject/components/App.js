import React, {Component} from "react";
import {
  Navigator,
} from "react-native";

import AddStudentContain from "./addStudent/AddStudentContain.js";
import ViewListStudentsContain from "./viewStudents/ViewListStudentsContain.js"; 
import UpdateStudentContain from "./updateStudent/UpdateStudentContain.js";

let pushNotification = require("../components/pushNotification/PushNotificationObject");

export default class App extends Component {
  constructor(props) {
    super(props);
    pushNotification.initialPushNotification();
  }

  addNewStudentTest(student) {    
    
  }

  renderScene(route, navigator) {
    switch(route.name) {
      case "addStudent": 
        return (
         <AddStudentContain 
            viewListStudents= {() => {navigator.push({name: "viewListStudents"})}}
          /> 
        );
      case "viewListStudents": 
        return (
          <ViewListStudentsContain 
            updateStudent= {
              (student) => {
                navigator.push({name: "updateStudent", passProps: {student: student}});
              }
            }
            viewAddStudent= {
              () => {
                navigator.push({name: "addStudent"});
              }
            }
          />
        );
      case "updateStudent": 
        return (
          <UpdateStudentContain
            student= {route.passProps.student}
            viewListStudents= {() => {navigator.push({name: "viewListStudents"})}}
          />
        );
    }
  }

  render() {
    return (
      <Navigator 
        initialRoute={{name: "viewListStudents"}}
        renderScene={this.renderScene}
      />
    );
  }
}

import React, {Component} from "react";

import {
    StyleSheet,
    View,
    Text,
    TextInput,
    ListView,
    TouchableOpacity,
    Picker
} from "react-native";

export default class AddStudent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            studentName: "",
            studentAge: 0,
            studentAddress: "",
            studentTitle: ""
        }
    }

    _addNewStudent() {
        let student = {
            studentName: this.state.studentName,
            studentAge: this.state.studentAge,
            studentAddress: this.state.studentAddress,
            studentTitle: this.state.studentTitle
        }
        this.props.addNewStudent(student);
    }

    render() {
        return (
            <View style={styles.enterData}>
                <View style={styles.rowInput}>
                    <Text style={styles.lable}> title: </Text>
                    <Picker
                        style={styles.input}
                        selectedValue= {this.state.studentTitle}
                        enabled= {true}
                        mode= "dropdown"
                        onValueChange= {(value, index) => {this.setState({studentTitle: value})}}>
                        <Picker.Item label="Mr" value="Mr"/>
                        <Picker.Item label="Mrs" value="Mrs"/>
                        <Picker.Item label="Miss" value="Miss"/>
                        <Picker.Item label="Sir" value="Sir"/>
                        <Picker.Item label="dr" value="dr"/>
                    </Picker>
                </View>
                <View style={styles.rowInput}>
                    <Text style={styles.lable}> name: </Text>
                    <TextInput
                          style={styles.input}
                          onChangeText={(text) => this.setState({studentName: text})}
                      />
                </View>
                <View style={styles.rowInput}>
                    <Text style={styles.lable}> age: </Text>
                    <TextInput
                        style={styles.input}
                        onChangeText={(text) => this.setState({studentAge: text})}
                    />
                </View>
                <View style={styles.rowInput}>
                    <Text style={styles.lable}> adddress: </Text>
                    <TextInput
                        style={styles.input}
                        onChangeText={(text) => this.setState({studentAddress: text})}
                      />
                </View>
                <TouchableOpacity onPress={() => {this._addNewStudent()}}>
                    <View style={styles.buttonAddStudent}>
                        <Text style={styles.textButton}> add student </Text>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

}

AddStudent.PropType= {
    addNewStudent: React.PropTypes.func.isRequired,
}

const styles = StyleSheet.create({

    rowInput: {
        flexDirection: "row",
    },
    lable: {
        flex: 1,
        marginTop: 20
    },
    input: {
        flex: 3
    },
    buttonAddStudent: {
        backgroundColor: "green",
        padding: 5,
        alignItems: "center",
        justifyContent: "center",
        margin: 10,
    },
    textButton: {
        color: "white"
    }

});

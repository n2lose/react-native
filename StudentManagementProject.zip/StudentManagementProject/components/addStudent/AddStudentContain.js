import React, {Component} from "react";
import {

} from "react-native";

import AddStudent from "../addStudent/AddStudent.js";

let StudentConstant = require("../../constant/StudentConstant");
let AppDispatcher = require("../../dispatcher/AppDispatcher");
let pushNotification = require("../pushNotification/PushNotificationObject");

export default class AddStudentContain extends Component {
    constructor(props) {
        super(props);
    }

    addStudent(student) {
        AppDispatcher.dispatch({
            action: StudentConstant.ADD_STUDENT,
            student: student
        });
        let messageContent = "student: " + student.studentName + " is added success";
        pushNotification.notificationAction(messageContent);

        this.props.viewListStudents();
    }

    render() {
        return (
            <AddStudent addNewStudent= {(student) => {this.addStudent(student)}}/>
        );
    }
}
let _ = require("underscore"),
    EventEmitter = require('events').EventEmitter;

let students = [{studentTitle: "Mr", studentId: 1, studentName: "Dao Xuan Tung", studentAge: 24, studentAddress: "thai nguyen"}];
const CHANGE_EVENT = "change";
let AppDispatcher = require("../dispatcher/AppDispatcher");
let StudentConstant = require("../constant/StudentConstant");
let count= 1;

function addStudent(student) {
    count += 1;
    student.studentId = count;
    students.push(student);
}

function updateStudent(student) {
    students = students.map(
        (studentElement) => {
            if(student.studentId === studentElement.studentId) {
                return student;
            }
            return studentElement;
        }
    );
}

function removeStudent(student) {
    students = students.filter(
        (studentElement) => {
            if(student.studentId !== studentElement.studentId) {
              return studentElement;
            }
        }
    );
}

let StudentStore  = _.extend(EventEmitter.prototype, {
    getStudents() {
        return students;
    },

    emitChange() {
        this.emit(CHANGE_EVENT);
    },

    addChangeListener(callback) {
        this.on(CHANGE_EVENT, callback);
    }
});

AppDispatcher.register((payload) => {
    switch(payload.action) {
        case StudentConstant.ADD_STUDENT: 
            addStudent(payload.student);
            StudentStore.emitChange();
            break;
        case StudentConstant.UPDATE_STUDENT:
            updateStudent(payload.student);
            StudentStore.emitChange();
            break;
        case StudentConstant.REMOVE_STUDENT: 
            removeStudent(payload.student);
            StudentStore.emitChange();
            break;
    }

})

module.exports = StudentStore;
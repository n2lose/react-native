
var Dispatcher = {
  login: function() {
    return {
      token: "fe37a156494cae1f2761ab2845e6cc3446010267",
      userProps: {
        id: 123,
        username: "tester"
      }
    };
  },
};

module.exports = Dispatcher;

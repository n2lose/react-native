'use strict';

import React from 'react';
import {
  AppRegistry,
} from 'react-native';

import Root from './App/Root';
AppRegistry.registerComponent('Sample', () => Root);

let NavigatorNavigationBarStyles = require('NavigatorNavigationBarStylesAndroid');

NavigatorNavigationBarStyles.General.TotalNavHeight = 48;

export default NavigatorNavigationBarStyles;

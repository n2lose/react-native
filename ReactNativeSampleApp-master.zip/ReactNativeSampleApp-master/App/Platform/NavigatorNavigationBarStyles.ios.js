export default require('NavigatorNavigationBarStylesIOS');

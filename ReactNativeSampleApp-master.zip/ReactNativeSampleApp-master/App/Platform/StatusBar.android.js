import React from 'react';

var StatusBar = {
  setNetworkActive(active) {
  },
  setHidden(hidden) {
  },
  setStyle(style) {
  },
};

export default StatusBar;

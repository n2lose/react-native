import flux from 'flux';
const {Dispatcher} = flux;

export default new Dispatcher();
